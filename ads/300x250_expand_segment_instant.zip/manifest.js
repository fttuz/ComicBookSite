FT.manifest({
	"filename":"300x250_expand_segment.html",
	"width":300,
	"height":250,
	"clickTagCount":1,
	"expand":{
		"width":500,
		"height":300,
		"indentAcross":0,
		"indentDown":0
	},
	"instantAds":[
		{"name":"panelText", "type":"text","default":"Comic Books Are Cool"}
	],
	"videos":[
		{"name":"video1", "ref":"14142/23001_comic_video_1"}
	]
});